<div class="row">
        <input type="search" class=" form-control" id="buscador">
        @foreach ($buscadores as $buscador )
        <div class="col-3"><br>
            <img src="{{url('upload/'.$buscador->images->image)}}" width="200" height="150">
            <p>Nombre: {{$buscador->name}}</p>
            <p>Descripcion: {{$buscador->description}}</p>
            <p>Tipo: {{$buscador->type}}</p>
        </div>
        @endforeach
    </div>
